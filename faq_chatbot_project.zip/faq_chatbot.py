import json
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Download necessary NLTK data
nltk.download('punkt')
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Load FAQ data
with open('faqs.json') as f:
    faqs = json.load(f)['faqs']

# Preprocess text
def preprocess(text):
    tokens = word_tokenize(text.lower())
    stop_words = set(stopwords.words('english'))
    return ' '.join([t for t in tokens if t.isalnum() and t not in stop_words])

questions = [faq['question'] for faq in faqs]
preprocessed_questions = [preprocess(q) for q in questions]

# TF-IDF Vectorization
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(preprocessed_questions)

# Chatbot loop
def chatbot():
    print("FAQ Chatbot (type 'exit' to quit)")
    while True:
        user_input = input("\nYou: ")
        if user_input.lower() == 'exit':
            print("Goodbye!")
            break
        preprocessed_input = preprocess(user_input)
        input_vec = vectorizer.transform([preprocessed_input])
        similarities = cosine_similarity(input_vec, tfidf_matrix).flatten()
        best_match_idx = similarities.argmax()
        if similarities[best_match_idx] > 0.2:
            print("Bot:", faqs[best_match_idx]['answer'])
        else:
            print("Bot: I'm sorry, I don't understand your question.")

if __name__ == '__main__':
    chatbot()
